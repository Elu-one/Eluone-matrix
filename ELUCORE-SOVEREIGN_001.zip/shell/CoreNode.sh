#!/bin/bash
# Sovereign node startup script