# EluOne Matrix

This is the sovereign AI and infrastructure repository for the EluOne system, authored by Luke Crawford.